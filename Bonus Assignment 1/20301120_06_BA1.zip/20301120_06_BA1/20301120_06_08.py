row=int(input())
col=int(input())
for i in range(0,row):
    for j in range(0,col):
        print("*", end="")
    print()