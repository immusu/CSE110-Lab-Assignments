num=int(input())
for i in range(0,num):
    for j in range(1,i+2):
        print(j, end="")
    print()