row=int(input())
col=int(input())
for i in range(0,row):
    for j in range(1,col+1):
        print(j, end="")
    print()