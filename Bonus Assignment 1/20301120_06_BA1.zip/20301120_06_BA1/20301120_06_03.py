for i in range(1,21):
    num = int(input())
    if num%2==0:
        print(num,"Even")
    else:
        print(num,"Odd")