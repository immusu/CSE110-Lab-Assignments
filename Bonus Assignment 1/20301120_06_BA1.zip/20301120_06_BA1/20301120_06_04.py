quan=int(input())
for i in range(0,quan):
    num = int(input())
    if num%2==0:
        print(num,"Even")
    else:
        print(num,"Odd")